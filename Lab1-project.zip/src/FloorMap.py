class FloorMap:
    def getObjectAtLocation(self):
        print("Object has been located")
    def getInitialRobotPosition(self):
        print("Robot check initial position")
    def getMinRowNum(self):
        print("Robot gets Min Row Number")
    def getMaxRowNum(self):
        print("Robot gets Max Row Number")     
    def getMaxColNum(self):
        print("Robot gets Max Column Number")
    def getMinColNum(self):
        print("Robot gets Min Column Number")